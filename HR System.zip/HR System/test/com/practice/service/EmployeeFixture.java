package com.practice.service;

import com.practice.domain.Employee;

public class EmployeeFixture {
	public static Employee createEmployee() {
		return new Employee(1, "Ashritha", "PB");
	}
}
