package com.practice.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.practice.domain.Contractor;
import com.practice.domain.Employee;
import com.practice.domain.FullTime;
import com.practice.domain.HRService;

public class HRServiceTest {
	private HRService hrService;

	@BeforeEach
	public void setup() {
		hrService = new HRService();
	}

	@Test
	public void addEmployeeTestWithFirstName() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getFirstName(), employee.getFirstName());
	}

	@Test
	public void addEmployeeTestWithLastName() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getLastName(), employee.getLastName());
	}
	
	@Test
	public void addEmployeeTestWithAddress() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getAddress(), employee.getAddress());
		assertEquals(searchedEmployee.getAddress().getAddressId(), employee.getAddress().getAddressId());
		assertEquals(searchedEmployee.getAddress().getCity(), employee.getAddress().getCity());
		assertEquals(searchedEmployee.getAddress().getCountry(), employee.getAddress().getCountry());
		assertEquals(searchedEmployee.getAddress().getLine1(), employee.getAddress().getLine1());
		assertEquals(searchedEmployee.getAddress().getLine2(), employee.getAddress().getLine2());
		assertEquals(searchedEmployee.getAddress().getState(), employee.getAddress().getState());
		assertEquals(searchedEmployee.getAddress().getZipcode(), employee.getAddress().getZipcode());
		
	}
	
	@Test
	public void addEmployeeTestWithPhone() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getPhone(), employee.getPhone());
		assertEquals(searchedEmployee.getPhone().getPhoneId(), employee.getPhone().getPhoneId());
		assertEquals(searchedEmployee.getPhone().getAreaCode(), employee.getPhone().getAreaCode());
		assertEquals(searchedEmployee.getPhone().getCountryCoe(), employee.getPhone().getCountryCoe());
		assertEquals(searchedEmployee.getPhone().getNumber(), employee.getPhone().getNumber());
	}
	
	@Test
	public void addEmployeeTestWithCompany() {
		List<Employee> employees = new ArrayList<Employee>();
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		employees.add(employee);
		employee.setEmployees(employees);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getCompanyId(), employee.getCompanyId());
		assertEquals(searchedEmployee.getCompanyName(), employee.getCompanyName());
		assertEquals(searchedEmployee.getEmployees().get(0).getEmployeeId(), employee.getEmployees().get(0).getEmployeeId());
		
	}
	
	@Test
	public void addEmployeeTestWithRole() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		Employee searchedEmployee = hrService.search(1);
		assertEquals(searchedEmployee.getRoles(), employee.getRoles());
		assertEquals(searchedEmployee.getRoles().get(0).getRoleId(), employee.getRoles().get(0).getRoleId());
		assertEquals(searchedEmployee.getRoles().get(0).getRoleName(), employee.getRoles().get(0).getRoleName());
		
		assertEquals(searchedEmployee.getRoles().get(1).getRoleId(), employee.getRoles().get(1).getRoleId());
		assertEquals(searchedEmployee.getRoles().get(1).getRoleName(), employee.getRoles().get(1).getRoleName());
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void addEmployeeTestWithContractor() {
		Contractor employee = ContractorFixture.createContractor();
		employee.setEmployeeId(1);
		employee.setFirstName("Ashritha");
		employee.setLastName("PB");
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		assertEquals(1, employee.getEmployeeId());
		assertEquals(new DateTime(2018),employee.getStart());
		assertEquals(new DateTime(2019),employee.getEnd());
		assertEquals(35.0f,employee.getHourlyRate(), 0.0f);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void addEmployeeTestWithFullTime() {
		FullTime employee = FullTimeFixture.createFullTime();
		employee.setEmployeeId(1);
		employee.setFirstName("Ashritha");
		employee.setLastName("PB");
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		assertEquals(1, employee.getEmployeeId());
		assertEquals(new DateTime(2020),employee.getStart());
		assertEquals(50000.0f,employee.getBaseSalaryPerYear(), 0.0f);
		assertEquals(55000.0f,employee.getBonusPerYear(),0.0f);
	}

	@Test
	public void removeEmployeeTest() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		assertEquals(1, hrService.removeEmployee(1));
	}
	@Test
	public void removeEmployeeTestWithNoCompanyEmployee() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		assertEquals(1, hrService.removeEmployee(1));
		assertEquals(0, employee.getEmployees().size());
	}
	@Test
	public void removeEmployeeTestForNotFound() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		assertEquals(-1, hrService.removeEmployee(50));
	}

	@Test
	public void searchByFirstNameAndLastNameTest() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		
		List<Employee> employees = hrService.search("Ashritha", "PB");
		for(Employee employeeObj: employees) {
			assertEquals("Ashritha", employeeObj.getFirstName());
			assertEquals("PB", employeeObj.getLastName());
		}
	}
	@Test
	public void searchByIdTest() {
		Employee employee = EmployeeFixture.createEmployee();
		employee.setAddress(AddressFixture.createAddress());
		employee.setPhone(PhoneFixture.createPhone());
		employee.setRoles(RoleFixture.createRole());
		employee.setCompanyId(1);
		employee.setCompanyName("ABC");
		hrService.addEmployee(employee);
		
		Employee employeeObject = hrService.search(1);
		assertEquals(1, employeeObject.getEmployeeId());
	}
	

}
