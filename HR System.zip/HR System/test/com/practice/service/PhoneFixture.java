package com.practice.service;

import com.practice.domain.Phone;

public class PhoneFixture {
	public static Phone createPhone() {
		return new Phone(1, "ABC", "123456789", "91");
	}
}
