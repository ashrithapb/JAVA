package com.practice.service;

import org.joda.time.DateTime;

import com.practice.domain.FullTime;

public class FullTimeFixture {
	public static FullTime createFullTime() {
		return new FullTime(new DateTime(2020), 50000.0f, 55000.0f);
	}
}
