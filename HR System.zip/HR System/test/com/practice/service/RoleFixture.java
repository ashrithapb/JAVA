package com.practice.service;

import java.util.ArrayList;
import java.util.List;

import com.practice.domain.Role;

public class RoleFixture {
	public static List<Role> createRole() {
		Role manager = new Role(1, "Manager");
		Role developer = new Role(2, "developer");
		List<Role> roles = new ArrayList<>();
		roles.add(manager);
		roles.add(developer);
		return roles;
	}
}
