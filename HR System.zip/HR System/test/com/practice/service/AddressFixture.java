package com.practice.service;

import com.practice.domain.Address;

public class AddressFixture {
	public static Address createAddress() {
		return new Address(1, "78727", "USA", "Tx", "Austin", "1002 avenue", "apt 17");
	}
}
