package com.practice.service;

import org.joda.time.DateTime;

import com.practice.domain.Contractor;

public class ContractorFixture {
	public static Contractor createContractor() {
		return new Contractor(new DateTime(2018), new DateTime(2019), 35.0f);
	}
}
