package com.practice.domain;

import java.util.ArrayList;
import java.util.List;

public class Company {
	private int companyId;
	private String companyName;
	private List<Employee> employees;

	public Company(int companyId, String companyName, List<Employee> employees) {
		this.companyId = companyId;
		this.companyName = companyName;
		this.employees = employees;
	}
	public Company() {
		
	}

	public int getCompanyId() {
		return companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public List<Employee> getEmployees() {
		if(employees == null) {
			employees = new ArrayList<>();
		}
		return employees;
	}

}
