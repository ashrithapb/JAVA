package com.practice.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HRService {
	private Map<Integer, Employee> db = new HashMap<>();

	public void addEmployee(Employee employee) {
		db.put(employee.getEmployeeId(), employee);
	}

	public int removeEmployee(int employeeID) {
		Employee employee = search(employeeID);
		if (employee != null) {
			db.remove(employeeID);
			return employeeID;
		}
		return -1;

	}

	public List<Employee> search(String firstName, String lastName) {
		List<Employee> dbEmployees = new ArrayList<Employee>(db.values());
		List<Employee> employees = new ArrayList<Employee>();
		for(Employee dbEmployee: dbEmployees)
			if(dbEmployee.getFirstName().equals(firstName) && dbEmployee.getLastName().equals(lastName)) {
				employees.add(dbEmployee);
			}
		return employees;
	}

	public Employee search(int employeeID) {
		return db.get(employeeID);
	}
}
