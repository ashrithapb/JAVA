package com.practice.domain;

public class Phone {
	private int phoneId;
	private String areaCode;
	private String number;
	private String countryCoe;

	public Phone(int phoneId, String areaCode, String number, String countryCoe) {
		this.phoneId = phoneId;
		this.areaCode = areaCode;
		this.number = number;
		this.countryCoe = countryCoe;
	}

	public int getPhoneId() {
		return phoneId;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public String getNumber() {
		return number;
	}

	public String getCountryCoe() {
		return countryCoe;
	}

}
