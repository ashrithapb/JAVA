package com.practice.domain;

public class Address {
	private int addressId;
	private String zipcode;
	private String country;
	private String state;
	private String city;
	private String line1;
	private String line2;

	public Address(int addressId, String zipcode, String country, String state, String city, String line1, String line2) {
		this.addressId = addressId;
		this.zipcode = zipcode;
		this.country = country;
		this.state = state;
		this.city = city;
		this.line1 = line1;
		this.line2 = line2;
	}

	public int getAddressId() {
		return addressId;
	}

	public String getZipcode() {
		return zipcode;
	}

	public String getCountry() {
		return country;
	}

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public String getLine1() {
		return line1;
	}

	public String getLine2() {
		return line2;
	}

}
