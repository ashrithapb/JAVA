package com.practice.service;

import com.practice.domain.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.joda.time.DateTime;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Scanner scanner1 = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);
		List<Role> roles = new ArrayList<Role>();
		List<Employee> employees = new ArrayList<>();
		HRService hrService = new HRService();
		Employee employee;
		boolean flag = true;
		while (flag) {
			System.out.println(
					"Choose the number 1: Add; 2: Remove; 3: Search using first name and last name; 4: Search using id; 5:exit");
			int inputChoice = scanner1.nextInt();
			switch (inputChoice) {
			case 1:
				while (true) {
					System.out.println("Is the employee Contractor? (Yes or No)");
					try {
						String isContractor = scanner2.nextLine();
						if (isContractor.equalsIgnoreCase("yes")) {
							System.out.println(
									"Please enter the Contract details: (Contract start date, Contract end date, hourly rate)");
							String contract_input = scanner.nextLine();
							StringTokenizer tokenizerContract = new StringTokenizer(contract_input);
							DateTime start = new DateTime(tokenizerContract.nextToken());
							DateTime end = new DateTime(tokenizerContract.nextToken());
							float hourlyRate = Integer.parseInt(tokenizerContract.nextToken());
							employee = new Contractor(start, end, hourlyRate);

							break;
						} else if (isContractor.equalsIgnoreCase("no")) {
							System.out.println(
									"Please enter the Full-time details: (Full time state date, Base salary per year, Bonus per year)");
							String fulltime_input = scanner2.nextLine();
							StringTokenizer tokenizerFullTime = new StringTokenizer(fulltime_input);
							DateTime startFullTime = new DateTime(tokenizerFullTime.nextToken());
							float baseSalaryPerYear = Float.parseFloat(tokenizerFullTime.nextToken());
							float bonusPerYear = Float.parseFloat(tokenizerFullTime.nextToken());
							employee = new FullTime(startFullTime, baseSalaryPerYear, bonusPerYear);
							break;
						} else {
							System.out.println("Please enter: 'Yes' or 'No' options only");
						}
					} catch (Exception e) {
						System.out.println("Entered input is not valid");
					}
				}
				System.out.println("Please enter the employee details to add in the following format");
				System.out.println(
						" Employee-Id, Employee-FirstName, Employee-LastName, Role-id, Role-name, Company-id, Company-Name, Phone-id, Phone-Areacode,"
								+ " Phone-Number, Phone-Countrycode, Address-id, Address-ZipCode, Address-Country, Address-State, Address-City, Address-line1, Address-line2 ");
				// 1 Ashritha PB 101 Software-developer 10 ABC 1 312 987654321 91 21 7890 US TX Dallas avenue-rd apt12 
				String input = scanner.nextLine();
				try {
					StringTokenizer tokenizer = new StringTokenizer(input);
					while (tokenizer.hasMoreElements()) {
						int employeeId = Integer.parseInt(tokenizer.nextToken());
						String employeeFirstName = tokenizer.nextToken();
						String employeeLasttName = tokenizer.nextToken();
						// Employee employee = new Employee(employeeID, employeeFirstName,
						// employeeLasttName);
						employee.setEmployeeId(employeeId);
						employee.setFirstName(employeeFirstName);
						employee.setLastName(employeeLasttName);

						int roleID = Integer.parseInt(tokenizer.nextToken());
						String roleName = tokenizer.nextToken();
						Role role = new Role(roleID, roleName);
						roles.add(role);
						employee.setRoles(roles);

						int companyID = Integer.parseInt(tokenizer.nextToken());
						String companyName = tokenizer.nextToken();
						employee.setCompanyId(companyID);
						employee.setCompanyName(companyName);
						employees = employee.getEmployees();
						employees.add(employee);
						employee.setEmployees(employees);
						

						int phoneID = Integer.parseInt(tokenizer.nextToken());
						String phoneAreaCode = tokenizer.nextToken();
						String phoneNumber = tokenizer.nextToken();
						String phoneCountryCode = tokenizer.nextToken();
						Phone phone = new Phone(phoneID, phoneAreaCode, phoneNumber, phoneCountryCode);
						employee.setPhone(phone);

						int addressID = Integer.parseInt(tokenizer.nextToken());
						String addressZipCode = tokenizer.nextToken();
						String addressCountry = tokenizer.nextToken();
						String addressState = tokenizer.nextToken();
						String addressCity = tokenizer.nextToken();
						String addressLine1 = tokenizer.nextToken();
						String addressLine2 = tokenizer.nextToken();
						Address address = new Address(addressID, addressZipCode, addressCountry, addressState,
								addressCity, addressLine1, addressLine2);
						employee.setAddress(address);
						hrService.addEmployee(employee);
						System.out.println("Employee added.");
					}

				} catch (Exception e) {
					System.out.println("Entered input is not valid");
				}
				break;
			case 2:
				System.out.println("Please enter the Employee id to remove");
				int idToRemove = scanner.nextInt();
				int employeeID = hrService.removeEmployee(idToRemove);
				if (employeeID != -1) {
					System.out.println("Removed the employee with ID: " + employeeID);
				} else {
					System.out.println("Employee id: " + idToRemove + " is not found.");
				}
				break;
			case 3:
				System.out.println("Please enter the Employee first name to search");
				String employeeFirstName = scanner.nextLine();
				System.out.println("Please enter the Employee last name to search");
				String employeeLastName = scanner.nextLine();
				List<Employee> searchedByNameResult = hrService.search(employeeFirstName, employeeLastName);
				if (searchedByNameResult.size() == 0) {
					System.out.println("Search match is not found.");
				} else {
					for (Employee employeeObj : searchedByNameResult) {
						System.out.println("Employee object found. Employee id is: " + employeeObj.getEmployeeId());
					}
				}

				break;
			case 4:
				System.out.println("Please enter the Employee ID to search");
				int employeeId = scanner.nextInt();
				Employee employeeObject = hrService.search(employeeId);
				if (employeeObject != null) {
					System.out.println("Employee object found and its firstName is " + employeeObject.getFirstName());
				} else {
					System.out.println("Employee object not found.");
				}
				break;
			case 5:
				flag = false;
				System.exit(0);
				break;
			default:
				System.out.println("Please choose any number from 1 to 5");

			}
		}
		scanner.close();
		scanner1.close();
		scanner2.close();
	}
}
